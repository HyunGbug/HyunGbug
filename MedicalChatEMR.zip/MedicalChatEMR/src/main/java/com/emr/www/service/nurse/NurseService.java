package com.emr.www.service.nurse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emr.www.repository.nurse.NurseRepository;
import com.emr.www.service.employee.EmployeeService;

@Service
public class NurseService {

    @Autowired
    private NurseRepository nurseRepository;
    @Autowired
    private EmployeeService employeeService;

}
