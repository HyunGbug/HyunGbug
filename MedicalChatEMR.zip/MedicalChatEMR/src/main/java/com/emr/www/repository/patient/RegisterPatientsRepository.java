package com.emr.www.repository.patient;


import org.springframework.data.jpa.repository.JpaRepository;

import com.emr.www.entity.patients.RegisterPatients;

public interface RegisterPatientsRepository extends JpaRepository<RegisterPatients, Integer> {
    //환자 주민번호 찾기
	RegisterPatients findBySecurityNum(String securityNum);
}