package com.emr.www.controller.nurse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.emr.www.entity.nurse.dto.NurseDto;
import com.emr.www.service.mail.MailService;
import com.emr.www.service.nurse.NurseService;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Controller
public class NurseController {

    // 로깅을 위한 Logger 생성
    private static final Logger logger = LoggerFactory.getLogger(NurseController.class);

    // NurseService를 사용하기 위해 Autowired로 의존성 주입
    @Autowired
    private NurseService nurseService;
    
    @Autowired
    private MailService mailService;

}