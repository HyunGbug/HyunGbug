package com.emr.www.service.doctor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emr.www.repository.doctor.DoctorRepository;
import com.emr.www.service.employee.EmployeeService;

@Service
public class DoctorService {
    
    @Autowired
    private DoctorRepository doctorRepository;
    
    @Autowired
    private EmployeeService employeeService;

}
